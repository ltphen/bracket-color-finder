# bracket-color-finder
made  this plugin  with a friend to be  able to  find local  css  colors  in your sheet 
hope  you guys will like , will  keep  on improving  it  thanks  